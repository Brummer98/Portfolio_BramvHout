import {
    BrowserRouter as Router,
    Routes,
    Route,
    useRoutes,
  } from "react-router-dom";

function App() {    
  return (
    <div>
        <h1>Type page in URL</h1>
    </div>
  );
}
export default App;