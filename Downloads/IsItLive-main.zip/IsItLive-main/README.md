# IsItLive
Live score is a metric to see how much content we have realized internally can be found on a retailer's website. Example: three attributes are shared with the Albert Heijn (Title, Brand and Description). AlbertHeijn has only put the Title and Brand online, the live score could then be 66%.

![alt](./assets/IsItLive-TopView.png)

## Table of Contents

- [Getting Started](#getting-started)
- [Contributors](#contributors)
- [License](#license)

## Getting Started

Start all service with the command below:

```sh
docker-compose -f docker-compose.yml up -d --build
```
The following endpoint are now avaible:

| Type | Endpoints                                                       |
|------|-----------------------------------------------------------------|
| Web  | <a href="http://localhost:3000">http://localhost:3000</a> |
| API  | <a href="http://localhost:4000">http://localhost:4000</a> |

## Software
* React JS
* Node JS
* Docker
* Bootstrap framework
* MongoDB
* Mui framework

## Requirements and userstories

#### Requirements

###### Functional
* Importing the data (Must have)
* Read the data (Must have)
* Synchronise data with the retailers data (Must have)
* An User has to be able to create an account (Could have)
* An User has to be able to login (Could have)
* Switch pages to other languages (Could have)
* Store proucts in the database (Could have)

###### Non-Functional
* Displaying the synced data in graphs.
* The data synchronisation has to be done within 5 minutes.

#### Userstories
* As supplier I want to be able to select a retailer to be able to check an overview of the products (must)
* As an user I want to be able to get the result to know if my products are online with percentage of how many are online (must)
* As an user I want to to have an graph on the overview for a quick check to see how many of my products are online (must)
* As an user I have to be able to login to have access to my credentials (should)
* As an user I want to be able to create an account and get access to the application (should)
* As an user I want to be able to set the application to another language when I'm not capable enough to read/understand English (should)
* As an user I want to be able to compare multiple retailers, so I can see which retailer performs best in getting the products live (could)
* As an user I wnat to be able to import products to synchronise (could)








## Agile 

As a team we chose to work the SCRUM agile method. So on a daily basis we had several meetings and created an environment where we summed up all of the issues withing
the project. Every meeting we took the time to look at the issues and speak up your mind about problems that we were having. That meant that we could all help eachother out and work out the issues one by one. 

#### Issues

We created issues to keep track of all the things that we need to do as a team, to finish the project. Everyone can create issues, not everyone can assign them to one another. Every issue comes with it's own description and checklist of things that must be done to finish the issue. 

![Issues](https://github.com/S3-DB03/IsItLive/blob/fa6bced679ec8261869ec4c1d202ef473aa03aff/img/Issues.png)

#### Working as a team
We managed to make it work as a team by making use of the ***agile method: SCRUM***. Also by communicating to one another and having meetings offline- aswell as online. If anyone of us had a problem that we faced, there was always someone to help out and eliminate the issue. Before we started working on the project, we looked at everyones needs and what they wanted to do within the project. For example, Dirk and i are more interested in the frontend and dus ***React JS***, so we started working on that. While te other team members decided to be more involved in the backend of the project, which worked well. Eventually we mamaged to make great progress every sprint and show ***WoC*** that we were able to create a webapp based on their requirements.

###### What went right?
To be fair we actually managed to do pretty well as a team and split the issues among us all. The communication was great and everyone was excited to work on the project. Creating the issues and working with GitHub to have insights into eachoter's work was also a good thing. We Helped eachother out where we could and made great progress all along. 

###### What went wrong?
There were one or two sprint assignments where we had to show what we've been working on, but we did'nt prepare ourselfs well enough. Which lead to all being muted when we sat down and just staring at the one team member that brought the laptop to start talking. So, that was'nt so great. We did manage to create time to prepare ourselfs better for the next assignment. 

## Workflow
#### How does the system work?

You begin at the home page, where you are pesented a dropdown component where you select a retailer from.
In this case, we limited the list of options to ***two*** retailers:
* Albertheijn
* Jumbo

![Selection dropdown retailers](https://github.com/S3-DB03/IsItLive/blob/2a58916be322447a331c114f72015c03511eaf3d/img/SelectRetailer.png)

After selecting one of these options, the page will redirect to the main page loaded in with the corresponding data based on what retailer was chosen.
You can see an overal score in the progress bar on the top of the page, which represents the score of all products shown in the table. The table on the page is loaded with all the products that the retailer has in stock, where you are able to see what livescore every product has.

#### Widgets
We decided to go with several components on a dashboard- like design, which we call ***widgets***. These widgets each contain something different to show.
The page consist out of the following widgets:

###### Live & Not Live - Score
This widget contains a progressbar where the overal live and not live score has been stacked into. This widget provides an easy overview to all of the products their average livescores. 

![Live and Not Live score](https://github.com/S3-DB03/IsItLive/blob/2fb1a095c38f23738c679c4e3c84f54fb9f95caa/img/LiveNotLive.png)

###### Total amount of products
This widget contains the exact amount of products that the chosen retailer has in stock.

![Live and Not Live score](https://github.com/S3-DB03/IsItLive/blob/2fb1a095c38f23738c679c4e3c84f54fb9f95caa/img/TotalAmount.png)

###### Products list
This widget contains a table which is filled with products that the retailer has in stock. The table consist out of the following columns:
* Ean
* Product description
* Status
* Similarity

![Live and Not Live score](https://github.com/S3-DB03/IsItLive/blob/2fb1a095c38f23738c679c4e3c84f54fb9f95caa/img/ProductsTable.png)

## Backend 
For the logic for this project we created a ***RestAPI*** and two ***scrapers***. We also worked with ***MongoDB*** to create schemes and save necessary data into the database. 

#### Scrapers
Two of our team members were frocussed on building scrapers so we could get the necessary data from the retailer's websites. The scrappers simply look over to one of the retailer's page and checks what is on it. It then ***scrapes*** the data and puts it into a file. That data we can compare with the list of products data we got from ***WoC***. 

#### RestAPI
The restapi is a backend tool where we can fetch data to be shown on the frontend of the project. The special thing within this RestAPI is that we managed to create a ***wrapper*** to fetch data more easily, instead of working with ***axios*** posts and gets. 

## Architecture

![Architecture](https://github.com/S3-DB03/IsItLive/blob/e5c50229215cf5021e1732ccd5417c0c15dfcb52/img/ArchitectureGP.png)

## Frontend

#### Design
We decided to go for a ***dashboard*** like style. This because we then could add several widgets, which seem to work quit well with this project.
At first we started of with a neutral page, which showed several components. After getting some useful feedback from WoC, we decided to go for the dashboard style. 
The colors used on the page and in the components work wel with eachother, you can see what is non-functional and what is functional on the webpage.
There was a little bit of research needed to see what kind of styling would be best for this project. This depended on what kind of data we where going to show and what kind of components the data was loaded in. We also decided to make use of ***Bootstrap*** and build the page using ***React JS***. 

###### Bootstrap
Bootstrap has a very easy to use and user friendly system, called the ***Grid system***. This system was very useful to us because we wanted the dashboard type of 
layout, and this was very easy to implement. You could add ***Containers***, ***Rows*** and ***Columns*** to create a nice layout which was also responsive. 

###### React JS

## Livescore
The livescore is momenteraly calculated by comparing one ***snapshot*** to the existing list of ***products***. It checks for three different things:
* EAN code
* Title 
* Description ( bullet points )

If any of these don't compare to the ones in the products list, we re-calulate the score and show it on the front of the page.

![Similarity score](https://github.com/S3-DB03/IsItLive/blob/85fc1d52f265b58c77d9246ded28ee6c3cc94215/img/SimilarityScore.png)

The livescore is calculated in the frontend of the project, since it doesn't need to be saved in the backend database.

## Contributors

This project is realized by the following contributors.

<a href="https://github.com/RikVanHaaren"><img alt="RikVanHaaren" src="https://avatars.githubusercontent.com/u/113465859?v=4" height="auto" width="100"></a>
<a href="https://github.com/Brummer98"><img alt="Brummer98" src="https://avatars.githubusercontent.com/u/95472264?v=4" height="auto" width="100"></a>
<a href="https://github.com/SanderMeulensteen"><img alt="SanderMeulensteen" src="https://avatars.githubusercontent.com/u/63857652?v=4" height="auto" width="100"></a>
<a href="https://github.com/Lil-durk"><img alt="Lil-durk" src="https://avatars.githubusercontent.com/u/50996310?v=4" height="auto" width="100"></a>
<a href="https://github.com/thisoban"><img alt="thisoban" src="https://avatars.githubusercontent.com/u/22049714?v=4" height="auto" width="100"></a>

## License

The MIT License (MIT) 2022 - [S3-DB03](https://github.com/S3-DB03/). Please have a look at the [LICENSE.md](LICENSE.md) for more details.



