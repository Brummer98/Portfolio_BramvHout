# IsItLive Rest API


### Develop

To run this application in development mode you can type the command below, make sure the database container is up!


``` sh
npm run dev
```

System environment variable overwrite .env file