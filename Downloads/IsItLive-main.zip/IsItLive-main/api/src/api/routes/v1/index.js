const express = require('express');
const productRoutes = require('./product.routes');
const snapshotRoutes = require('./snapshot.routes');
const retailerRoutes = require("./retailer.routes")

const router = express.Router();


router.get('/status', (req, res) => res.send(JSON.stringify({status: "OK"})));

router.use('/products', productRoutes);
router.use('/snapshots', snapshotRoutes);
router.use('/retailers',retailerRoutes );

module.exports = router;