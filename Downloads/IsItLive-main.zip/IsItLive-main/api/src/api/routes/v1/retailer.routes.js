const express = require('express');
const controller = require('../../controllers/retailer.controller');



const router = express.Router();

router
.route('/')
.get(controller.findAll)
.post(controller.create);

router
.route('/:retailerId')
.get(controller.findById);

module.exports = router;
