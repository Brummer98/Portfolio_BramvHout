const httpStatus = require('http-status');

// Models
const Snapshot = require('../models/snapshot.model');

 exports.create = async (req, res, next) => {
    try {
        const snapshot = new Snapshot(req.body);
        snapshot.populate("product");
        const savedSnapshot = await snapshot.save();
        res.status(httpStatus.CREATED);
        res.json(savedSnapshot);
    } catch (error) {
      next(httpStatus.INTERNAL_SERVER_ERROR).json({ message: error.message });
    }
  };

exports.list = async (req, res, next) => {

    let filter = {};

    if(req.query.product_id != undefined) filter.product = req.query.product_id;

    try {
        const snapshots = await Snapshot.find(filter).sort({"createdAt":-1}).limit( req.query.limit | 0);
        res.json(snapshots);
    } catch (error) {
      next(httpStatus.INTERNAL_SERVER_ERROR).json({ message: error.message });
    }
};

exports.findById = async(req, res, next)=>
{
  console.log(req.params.snapshotId);
    try {
        const snapshot = await Snapshot.findById( req.params.snapshotId);
        console.log(snapshot);
        res.send(snapshot) 
    } catch (error) {
      next(httpStatus.INTERNAL_SERVER_ERROR).json({message: error.message});
    }
}