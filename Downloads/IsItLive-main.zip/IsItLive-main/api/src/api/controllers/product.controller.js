const httpStatus = require("http-status");

// Models
const Product = require("../models/product.model");

exports.create = async (req, res, next) => {
    try {
        const product = new Product(req.body);
       product.populate("retailer");
       if(product.retailer != null){
        if(product.dynamicFields.length != 0 ){
            const savedProduct = await product.save();
            res.status(httpStatus.CREATED);
            res.json(savedProduct);
        }else{
            res.status(httpStatus.INTERNAL_SERVER_ERROR).json({"message": "Product requires at least 1 dynamic field."})
        }
       }else{
        res.status(httpStatus.INTERNAL_SERVER_ERROR).json({"message": "Product requires a valid retailer ID."})
       }        
    } catch (error) {
      next(httpStatus.INTERNAL_SERVER_ERROR).json({ message: error.message });
    }
  };


exports.list = async (req, res, next) => {
    let filter = {};
    if(req.query.retailer_id != undefined) filter.retailer = req.query.retailer_id;

  try {
    const products = await Product.find(filter);
    res.json(products);
  } catch (error) {
    //next(httpStatus.INTERNAL_SERVER_ERROR).json({ message: error.message });
    res.status(500).send();
  }
};

exports.findByProductId = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.productId);
    res.json(product);
  } catch (error) {
    next(httpStatus.INTERNAL_SERVER_ERROR).json({ message: error.message });
  }
};