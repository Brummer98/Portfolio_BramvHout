const httpStatus = require('http-status');

const Retailer  = require("../models/Retailer.model")

exports.create = async (req, res, next) => {
    try {
        const retailer = new Retailer(req.body);
        const savedRetailer = await retailer.save();
        res.status(httpStatus.CREATED);
        res.json(savedRetailer);
    }
    catch(error){
        res.status(httpStatus.INTERNAL_SERVER_ERROR).json({message: error.message})
    }
};

exports.findAll = async (req, res, next)=>{
    try{
      const retailers = await Retailer.find(req.query);
      res.json(retailers);
    }catch(error){
        next(httpStatus.INTERNAL_SERVER_ERROR).json({message: error.message});
    }
}

exports.findById = async(req, res, next)=>{
    try {
        const product = await Retailer.findById(req.params.retailerId);
        res.json(product);
      } catch (error) {
        console.log(error.message);
        //next(httpStatus.INTERNAL_SERVER_ERROR).json({ message: error.message });
      }
}