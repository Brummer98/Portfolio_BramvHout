const mongoose = require("mongoose");
const dynamicField = require("./dynamicField.model");

const snapshotSchema  = new mongoose.Schema(
    {
        product: {type: mongoose.Schema.Types.ObjectId, 
            ref: 'product'
            },
        dynamicFields: {
            type: [dynamicField],
        }
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model("Snapshot", snapshotSchema);