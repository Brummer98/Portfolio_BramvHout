const mongoose = require("mongoose");
const dynamicField = require("./dynamicField.model");

const productSchema  = new mongoose.Schema(
    {
        retailer: {type: mongoose.Schema.Types.ObjectId, 
        ref: 'retailer'
        },
        
        dynamicFields: {
            type: [dynamicField],
        }
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model("product", productSchema);