const mongoose = require("mongoose");

const retailerSchema  = new mongoose.Schema(
    {
        name: {
            required: true,
            type: String,
        },
        image: {
            type: String,
        }
        
    },
    {
        timestamps:true,
    }
);

module.exports = mongoose.model("retailer", retailerSchema);