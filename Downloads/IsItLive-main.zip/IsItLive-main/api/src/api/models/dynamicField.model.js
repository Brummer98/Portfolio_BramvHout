const mongoose = require("mongoose");

const dynamicFieldSchema  = new mongoose.Schema(
    {
        fieldKey: {
            required: true,
            type: String,
        },
        fieldValue: {
            type: String,
        },
        fieldValues: {
            type: [String],
            default: undefined
        },
        isSearchable:{
            type: Boolean
        },
        priority:{
            type: Number
        },
        
    },
    {
        _id : false
    }
);

module.exports = dynamicFieldSchema;