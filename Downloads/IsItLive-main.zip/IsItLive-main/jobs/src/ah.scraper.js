function AHScraper(){
    
    const { AHShopClient } = require("@rikvanhaaren/ah_shop_api");
    const client = new AHShopClient();
   

}
auth.prototype.getProduct = async function (product) {

}

module.exports = AHScraper;