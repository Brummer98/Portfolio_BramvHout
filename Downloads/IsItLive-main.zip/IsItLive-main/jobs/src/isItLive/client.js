const http = require("http");

// Main function
function client(){
    this.hostname = 'localhost';
}

client.prototype.getProducts = async function (retailerId) {
    return await this.get(`/api/v1/products${(retailerId)?"?retailer_id="+retailerId:""}`);
};

client.prototype.saveSnapshotProduct = async function (body) {
    return await this.post(`/api/v1/snapshots`, body);
};


// Methods
client.prototype.get = function (path) { 
    return this.request(path, "GET");
}; 

client.prototype.post = function (path, body) {
    return this.request(path, "POST", body);
};

// Request
client.prototype.request = async function (path, method, body) {
    var options = {
        method,
        port: 4000,
        hostname: this.hostname,
        path,
        headers: {
            'Content-Type': 'application/json'
        }
    };



    return new Promise((resolve, reject) => {
        var req = http.request(options, function (res) {
            var chunks = [];

            res.on("data", function (chunk) {
                chunks.push(chunk);
            });

            res.on("end", function (chunk) {
                var body = Buffer.concat(chunks);

                return resolve(JSON.parse(body));
            });

            res.on("error", function (error) {
                return reject(error);
            });
        });
    
        if (method == "POST") 
            req.write(JSON.stringify(body));

        req.end();
    });
};

module.exports = client;