function mapObjectToDynamicObject(object){
    let result = [];

    Object.keys(object).forEach(key => {
        let dynamicField = {fieldKey:key}

        if(typeof object[key] === 'string')
            dynamicField.fieldValue = object[key];

        if(Array.isArray(object[key]))
            dynamicField.fieldValues = object[key];

        result.push(dynamicField)
    });

    return result;
}

function mapDynamicObject(object){
    let resultObject = {}

    for (const field of object) {
        resultObject[field.fieldKey] = (field.fieldValue)?field.fieldValue:field.fieldValues;
    }
    
    
    return resultObject;
}

module.exports = {mapObjectToDynamicObject, mapDynamicObject};