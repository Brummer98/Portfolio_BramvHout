const Client = require('./isItLive/client');
//const Jumboscraper = require('./jumbo.scraper');

//const jumboscaper = new Jumboscraper();
const client = new Client();

client.getProducts().then(products => {
    console.log(products);
    
    /*products.forEach(product => {
        switch (product.retailer) {
            case "albertHeijn":
                console.log("Retailer albert heijn!");
                break;

            case "jumbo":
                jumboscaper.getProduct().then(product => client.saveSnapshotProduct(product));
                console.log("Retailer jumbo!");
                break;
        
            default:
                console.log("Retailer unkown!");
                break;
        }
    });*/
});