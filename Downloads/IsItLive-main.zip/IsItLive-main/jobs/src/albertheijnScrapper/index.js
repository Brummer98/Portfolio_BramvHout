const { default: parse } = require("node-html-parser");
const fs = require('fs');
const { AHShopClient } = require("@rikvanhaaren/ah_shop_api");
const IsItLiveClient = require('../isItLive/client');
const {mapObjectToDynamicObject, mapDynamicObject} = require('../isItLive/helper');

const ahClient = new AHShopClient();
const isItLiveClient = new IsItLiveClient();

const config = {
   retailerId: "63775dca4a8310467a90f33d",
}

isItLiveClient.getProducts(config.retailerId).then(async products => {
    var resultLog = [];

    for (const product of products) {
        var startTime = performance.now()
        let fieldsObject = mapDynamicObject(product.dynamicFields)
        let snapshotDynamicFields;

        let log = {
            ean: fieldsObject.ean,
            opco: fieldsObject.opco,
            productDescription: fieldsObject.productDescription,
        };

        if(fieldsObject.hasOwnProperty('ean') && fieldsObject.hasOwnProperty('productDescription')) {
            let productResult;
            try {
                productResult = await getProductByDescriptionThatEqualsEan(fieldsObject.ean, fieldsObject.productDescription);
                log.linkerStatus = { status: true, message: "Linker successfully found a product based on ean an description"}
            } catch (error) {
                log.linker = { status: false, message: error.message}
            }

            try {
                let resultFields = await getAhProductByID(productResult.id);
                resultFields.ean = String(fieldsObject.ean);
                resultFields.opco = productResult.brand;

                snapshotDynamicFields =  mapObjectToDynamicObject(resultFields);
                log.foundStatus = { status: true, message: "Product is successfully found in AH webshop"}
            } catch (error) {
                log.foundStatus = { status: false, message: error.message}
            }
        }

        // Save snapshot in IstItLive
        if(snapshotDynamicFields) {
            await isItLiveClient.saveSnapshotProduct({
                product: product._id,
                dynamicFields:snapshotDynamicFields
            })

            log.requestStatus = { status: true, message: `Product is successfully created in IsItLive`}
        } else {
            log.requestStatus = { status: false, message: `Product request is missing required properties: "ean", "productDescription"!`}
        }

        var endTime = performance.now()
        log.processTime = `${Math.trunc(endTime - startTime)}ms`;

        await resultLog.push(log)
    }


    await fs.writeFile('./src/albertheijnScrapper/log.json', JSON.stringify(resultLog, null,2), err => {
        if (err) {
          console.error(err);
        }
        //console.log(resultLog);
      });
});

async function getProductByDescriptionThatEqualsEan(ean, productDescription) {
    return (product = await ahClient
        .product()
        .getProductByName(productDescription, { size: 1000 })
        .then((result) => {
            if (result.cards == undefined) throw new Error(`ERROR: productDescription: '${productDescription}' has 0 results!`);

            let productResult = {};

            for (const card of result.cards) {
                for (const product of card.products) {
                    // Check if EAN equals the product GTINS
                    if (product.gtins.includes(parseInt(ean))) {
                        // Get product parent and overwrite child
                        if (Object.keys(productResult).length === 0 || product.gtins.length == 1) {
                            productResult = product;
                        }
                    }
                }
            }

            if (Object.keys(productResult).length === 0) throw new Error(`ERROR: there are ${result.cards.length} products found on the product description. But non matched the EAN code '${ean}'`);

            return productResult;
        }));
}

async function getAhProductByID(productId) {
    return ahClient
        .product()
        .getProductByID(productId)
        .then((result) => {
            const document = parse(result);
            const article = document.querySelector('article')

            if(!article)
                throw new Error(`No product found based on ProductID: ${productId}`);

            // Get elements from body by attribute
            const productSummary = article.querySelector('[data-testhook="product-summary"]');
            const productItems = productSummary.querySelectorAll("li");

            // Get values from the elements
            const productItems_array = productItems.map(function (item) {
                return item.innerHTML;
            });
            const productDescription_value = productSummary.querySelector("p").innerHTML;
            const productSummary_value = productSummary.innerHTML;

            // Get unitsize
            const productUnitSize = article.querySelector('[data-testhook="product-unit-size"]').innerHTML

            return {
                description: productDescription_value,
                points: productItems_array,
                optionalDescription: productSummary_value,
                unitSize: productUnitSize,
            };
        });
}