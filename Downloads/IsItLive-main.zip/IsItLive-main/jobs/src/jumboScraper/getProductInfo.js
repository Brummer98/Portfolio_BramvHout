async function getProductInfo(productId) {
  var https = require('follow-redirects').https;
  const { parse } = require("node-html-parser");
  var options = {
    'method': 'GET',
    'hostname': 'www.jumbo.com',
    'path': '/producten/' + productId,
    'headers': {
      'User-Agent': 'jumbo_scraper',
    },
    'maxRedirects': 20
  };
  
  return await new Promise((resolve, reject) => {
    var req = https.request(options, function (res) {
      var chunks = [];

      res.on("data", function (chunk) {
        chunks.push(chunk);
      });

      res.on("end", function (chunk) {
        var document = '';
        try {
          var body = Buffer.concat(chunks);
          document = parse(body);
        } catch (error) {
          const errorMessageParse = 'Could not find the page belonging to the product!';
          return errorMessageParse
        }

        // Get productTitle
        var productTitle = '';
        try {
          const strong = document.querySelector('strong');
          const title = strong.childNodes[0]._rawText;
          productTitle = title;
        } catch (error) {
          productTitle = 'Could not find the title belonging to the product';
        }

        // Get ShortDescription1
        // Part 1 + Bullet Points
        var shortDescriptionPart1 = '';
        try {
          const findShortDescriptionP1 = document.querySelectorAll('p.block');
          findShortDescriptionP1[1].childNodes.forEach(childNode => {
            if (childNode._rawText != undefined) {
              shortDescriptionPart1 = shortDescriptionPart1 + childNode._rawText + " ";
            }
          });
        } catch (error) {
          shortDescriptionPart1 = 'Part 1 of short description 1 is not available!';
        }
        shortDescriptionPart1 = shortDescriptionPart1.replace(/\s+/g, ' ').trim();
        // Bullet Points
        var bulletPointsSplit = shortDescriptionPart1.split(" - ");
        if (bulletPointsSplit[1] == undefined) {
          var bulletPointsSplit = shortDescriptionPart1.split(" • ");
        }
        var bulletPointsFill = "";
        for (let i = 1; i < bulletPointsSplit.length; i++) {
          bulletPointsFill = bulletPointsFill + '"' + bulletPointsSplit[i].trim() + '"' + "  ";
        }
        const bulletPoints = "[" + bulletPointsFill.trim().split("  ") + "]";

        // Part 1
        var shortDescPart1 = "";
        splittedShortDescriptionPart1 = shortDescriptionPart1.split("\n");
        splittedShortDescriptionPart1.forEach(part => {
          shortDescPart1 = shortDescPart1 + part;
        })

        // Part 2
        var shortDescriptionPart2 = '';
        try {
          const findShortDescriptionP2 = document.querySelector('[analytics-tag="manufacturer collapsible"]');
          const p = findShortDescriptionP2.querySelector('p');
          p.childNodes.forEach(childNode => {
            if (childNode._rawText != null || childNode._rawText != undefined) {
              shortDescriptionPart2 = shortDescriptionPart2 + childNode._rawText + "\n";
            }
          });
        } catch (error) {
          shortDescriptionPart2 = 'Part 2 of short description 1 is not available!';
        }
        splittedShortDescriptionPart2 = shortDescriptionPart2.split("\n");
        var shortDescription1 = shortDescPart1 + " ";
        splittedShortDescriptionPart2.forEach(part => {
          if (part != undefined) {
            shortDescription1 = shortDescription1 + part + " ";
          }
        });

        // Get ShortDescription1
        var shortDescription2 = 'ShortDescription2 is not found!';

        // Get EAN-number from webpage
        var foundEan = '';
        try {
          const findEan = document.querySelectorAll('script');
          const eanScript = findEan[8];
          const scriptChildNode = eanScript.childNodes;
          const scriptChildNodeSplit = scriptChildNode[0]._rawText.split('ean:"');
          const foundEanArray = scriptChildNodeSplit[1].split('",category');
          foundEan = foundEanArray[0];
        } catch (error) {
          foundEan = 'Could not find the ean number';
        }
        // Return values
        const productBodyJson = JSON.parse('{"ean":"' + foundEan + '", "title": "' + productTitle.trim() + '", "shortDescription1":"' +
          shortDescription1.trim() + '", "shortDescription2":"' + shortDescription2.trim() + '", "bulletPoints":' + bulletPoints + '}');
        return resolve(productBodyJson)

      });

      res.on("error", function (error) {
        console.error(error);
        return reject(error)
      });
    });

    req.end();
  })

}

module.exports = { getProductInfo }