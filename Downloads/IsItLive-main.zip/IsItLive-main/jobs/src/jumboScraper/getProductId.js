async function getProductId(ean){
  const https = require('https');

  return await new Promise((resolve, reject) => {
    https.get('https://mobileapi.jumbo.com/v17/search?q=' + ean, (resp) => {

      let data = '';
      let product = '';
    
      // A chunk of data has been received.
      resp.on('data', (chunk) => {
        data += chunk;
      });
    
      // The whole response has been received. Print out the result.
      resp.on('end', () => {
        try {
          product = JSON.parse(data).products.data;
        const productId = (({ id }) => ({ id }))(product[0]);
        const productIdString = productId.id;
        return resolve(productIdString)
        } catch (error) {
          const errorMessage = 'Could not find a productId belonging to the given EAN-number!';
          return errorMessage
        }
        
      });
    
    }).on("error", (err) => {
      console.log("Error: " + err.message);
      return reject(err.message)
    });
  }) 
}

module.exports = { getProductId };