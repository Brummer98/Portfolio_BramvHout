const { default: parse } = require("node-html-parser");
const fs = require('fs');
const { getProductId } = require("./getProductId");
const { getProductInfo } = require("./getProductInfo");
const IsItLiveClient = require('../isItLive/client');
const {mapObjectToDynamicObject, mapDynamicObject} = require('../isItLive/helper');

const isItLiveClient = new IsItLiveClient();

const config = {
   retailerId: "6389f154345857f06428f345",
}

isItLiveClient.getProducts(config.retailerId).then(async products => {
    var resultLog = [];

    for (const product of products) {
        var startTime = performance.now()
        let fieldsObject = mapDynamicObject(product.dynamicFields)
        let snapshotDynamicFields;

        let log = {
            ean: fieldsObject.ean,
            title: fieldsObject.title
        };

        if(fieldsObject.hasOwnProperty('ean') && fieldsObject.hasOwnProperty('title')) {
            let productResult;
            try {
                productResult = await getProductId(fieldsObject.ean);
                log.productStatus = { status: true, message: "Product successfully found based on ean"}
            } catch (error) {
                log.linker = { status: false, message: error.message}
            }

            try {
                let resultFields = await getProductInfo(productResult);
                snapshotDynamicFields =  mapObjectToDynamicObject(resultFields);
                log.foundStatus = { status: true, message: "Product is successfully found online in the Jumbo webshop"}
            } catch (error) {
                log.foundStatus = { status: false, message: error.message}
            }
        }

        // Save snapshot in IstItLive
        if(snapshotDynamicFields) {
            await isItLiveClient.saveSnapshotProduct({
                product: product._id,
                dynamicFields:snapshotDynamicFields
            })

            log.requestStatus = { status: true, message: `Product snapshot is successfully created in IsItLive`}
        } else {
            log.requestStatus = { status: false, message: `Product request is missing required properties: "ean", "productDescription"!`}
        }

        var endTime = performance.now()
        log.processTime = `${Math.trunc(endTime - startTime)}ms`;

        console.log(log)
        await resultLog.push(log)
        fs.writeFile('./src/jumboScraper/log.json', JSON.stringify(resultLog, null,2), err => {
            if (err) {
              console.error(err);
            }
        });
    }
});