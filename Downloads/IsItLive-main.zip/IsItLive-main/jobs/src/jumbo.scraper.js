const getId = require("./jumboScraper/getProductId");
const getInfo = require("./jumboScraper/getProductInfo.js");

// get product

//snapshot product

//send to restapi to save in database


function jumboScrapper(){

}

auth.prototype.getProduct = async function (ean) {
    var productIdString = '';
    var productInfoString = '';

    async function getProductIdAsync() {
        productIdString = await getId.getProductId(ean)
    }

    getId.getProductId(ean).then(productId => {
        try {
            async function getProductInfoAsync() {
                getInfo = await getInfo.getProductInfo(productId, ean);
            }
        } catch (error) {
            console.log(error);
        }

        try {
            getInfo.getProductInfo(productId, ean).then(productInfo => {
                console.log(productInfo);
            })
        } catch (error) {
            console.log(error);
        }
    });
}

module.exports = jumboScrapper;