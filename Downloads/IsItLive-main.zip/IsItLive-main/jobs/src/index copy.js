const http = require('http');
const { HelloMom } = require('./jumbo.scraper');

HelloMom("Bilbo");


// Get all products
async function GetAllProducts(){
    http.get('http://localhost:4000/api/v1/products', res => {
    let data = [];
    const headerDate = res.headers && res.headers.date ? res.headers.date : 'no response date';
    console.log('Status Code:', res.statusCode);
    console.log('Date in Response header:', headerDate);
  
    res.on('data', chunk => {
      data.push(chunk);
    });
  
    res.on('end', () => {
      console.log('Response ended: ');
      const users = JSON.parse(Buffer.concat(data).toString());
        console.log(users);
    });
  }).on('error', err => {
    console.log('Error: ', err.message);
  });
}



































//http://localhost:4000/api/v1/products
  /*http.get('http://localhost:4000/api/v1/products', res => {
    let data = [];
    const headerDate = res.headers && res.headers.date ? res.headers.date : 'no response date';
    console.log('Status Code:', res.statusCode);
    console.log('Date in Response header:', headerDate);
  
    res.on('data', chunk => {
      data.push(chunk);
    });
  
    res.on('end', () => {
      console.log('Response ended: ');
      const users = JSON.parse(Buffer.concat(data).toString());
        console.log(users);
    });
  }).on('error', err => {
    console.log('Error: ', err.message);
  });*/

















































//const jumboscraper= require("./jumbo.scraper");

/*async () => {
const products = await GetCurrentProduct();

products.forEach(product => {
    switch (product.retailer) {
        case "jumbo":
          //  jumboscraper.CreateSnapshot(product);
            break;
        case"albertHeijn":
      //  ahscraper.CreateSnapshot(product);
      console.log("appie")
            break;
        default:
            break;
    }
});
}
GetCurrentProduct();
// make rest api call products (get list of products)
async function  GetCurrentProduct() {
    try{
        const response = await axios.get ("http/localhost:4000/api/v1/products")
        console.log(response);
        return response;
    }
    catch(error){
        console.error(error);
    }
    }
 
 //call api 
 //get all products
 //return products

//wich retailer it is and if it already exist

*/