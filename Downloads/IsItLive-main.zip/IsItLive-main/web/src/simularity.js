const similarity = require("similarity");
const { argv } = require("node:process");

const linkedProducts = require("./data/ahProducts.json");
const syncedProducts = require("./data/ahProducts_synced.json");

// Get EAN from argument
const ean = argv[2];

// Get sync product by EAN
let existingLinkedObject = objectToExpectedProduct(linkedProducts.find((o) => o.ean == ean));
if (existingLinkedObject == undefined) 
	throw new Error("Product norm doesn't exist yet, please create one first!");

// Get expected product
//let lastedSyncedProduct = syncedProducts.find((o) => o.ean == ean);
let syncedProductsMatchedEan = syncedProducts.filter(o => o.ean == ean);
if (syncedProductsMatchedEan == undefined || syncedProductsMatchedEan.length < 1) 
	throw new Error("No sync found, please sync the product first!");

// Sort products on data
syncedProductsMatchedEan.sort(function(a,b){
    return new Date(b.createAt) - new Date(a.createAt);
});

let lastedSyncedProduct = objectToExpectedProduct(syncedProductsMatchedEan[0]);

// Retrun simularity
const simularityKeysOfObject = similarityKeyEqualsOrNot(existingLinkedObject, lastedSyncedProduct);
const simularityCompleetObject = similarity(JSON.stringify(existingLinkedObject), JSON.stringify(lastedSyncedProduct), { sensitive: true }) * 100;
console.log({
    keySimularity: simularityKeysOfObject,
    objectSimularity: simularityCompleetObject,
});



/* Helpers */
function similarityKeyEqualsOrNot(obj1, obj2) {
    let totalItems = 0;
    let equals = 0;

    for (const key of Object.keys(obj1)) {
        // Is value array
        if (Array.isArray(obj1[key])) {
            for (let index = 0; index < obj1[key].length; index++) {
                if (obj1[key][index] == obj2[key][index]) equals++;

                totalItems++;
            }
        } else {
            if (obj1[key] == obj2[key]) equals++;

            totalItems++;
        }
    }

    //return (100 / totalItems) * equals;
    return `${equals} of the ${totalItems} are equal`;
}

function objectToExpectedProduct(obj) {
    return {
        description: obj.description,
        points: obj.points,
        optionalDescription: obj.optionalDescription,
    }
}