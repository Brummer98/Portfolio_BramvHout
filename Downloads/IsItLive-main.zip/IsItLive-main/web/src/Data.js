export const ChartData = [
    {
      id: 0,
      liveNotLive: "Not live",
      percentage: 33.3,
    },
    {
      id: 1,
      liveNotLive: "Live",
      percentage: 66.6,
    }
  ];