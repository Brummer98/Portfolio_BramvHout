import Dropdown from "react-bootstrap/Dropdown";
import IsItLiveAPIClient from "../services/IsItLiveAPI";
const isItLiveAPIClient = new IsItLiveAPIClient();

//Old imports
//import { Dropdown } from "rsuite";
//import "./style.css";

export default function RetailerDropDown({ options, selected }) {
  return (
    <div>
      <Dropdown className="dropdownButton">
        <Dropdown.Toggle variant="">
          <img
            src={options.image}
            alt={options.name}
            width="50"
          />
          {options.name} {options == selected ? `${options.name}` : "niet deze"}
        </Dropdown.Toggle>

        <Dropdown.Menu>
        
        {options.map((option) => (
          <Dropdown.Item href={option.name}>{option.name}</Dropdown.Item>
        // <a key={option._id} href={option.name}>
        //   {option.name} {option == selected ? "deze ja" : "niet deze"}
        // </a>
      ))}
        </Dropdown.Menu>
        <Dropdown.Menu>
        {options.map((retailer) => (
          <Dropdown.Item href={retailer.name}>{retailer.name}</Dropdown.Item>
        ))}
      </Dropdown.Menu>
      </Dropdown>
      
    </div>
  );
}
