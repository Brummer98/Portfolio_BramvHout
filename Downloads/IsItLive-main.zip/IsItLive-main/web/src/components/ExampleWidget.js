import React from "react";
import Dropdown from "react-bootstrap/Dropdown";

// Imports
import { Routes, Route, useParams } from "react-router-dom";
import { useState, useEffect } from "react";


function ExampleWidget({ Percentage }) {
    return (
       <div>
            {Percentage}
       </div>
    );
}

export default ExampleWidget;
