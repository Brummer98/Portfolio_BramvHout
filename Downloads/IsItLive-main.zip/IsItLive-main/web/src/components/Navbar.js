import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
// Imports
import { Routes, Route, useParams, Navigate } from "react-router-dom";
import React, { useState, useEffect, useRef } from "react";

// Component imports
import Form from 'react-bootstrap/Form';
import ListGroup from 'react-bootstrap/ListGroup';

// Data imports
import MapDynamicObject from "../services/Mapper";
import IsItLiveAPIClient from "../services/IsItLiveAPI";
const isItLiveAPIClient = new IsItLiveAPIClient();

function NavbarTop() {
  // Id and Retailer data
  const [retailers, setRetailers] = useState([]);
  const retailersRef = useRef();
  retailersRef.current = retailers;
  const [products, setProducts] = useState([]);
  const productsRef = useRef();
  productsRef.current = products;
  const [searchOptions, setSearchOptions] = useState([]);

  useEffect(() => {
    isItLiveAPIClient.products.getAll().then(products => setProducts(products));
    isItLiveAPIClient.retailers.getAll().then(retailers => setRetailers(retailers));
}, []);

const handleSearch = event => {
  let searchValue = event.target.value;

  if(searchValue.length > 1){
    let searchResult = [];
    const retailersResult = retailersRef.current.filter(retailer => retailer.name.includes(searchValue));
    for (const retailer of retailersResult) {
      searchResult.push({title: retailer.name, link: "/retailer/"+retailer.name});
    }

    const productsResult = productsRef.current.filter(product => MapDynamicObject(product.dynamicFields).ean.includes(searchValue));
    for (const product of productsResult) {
      let dynamic = MapDynamicObject(product.dynamicFields);
      let productRetailer = retailersRef.current.find(retailer => retailer._id == product.retailer)
      searchResult.push({title: `${productRetailer.name} - ${dynamic.ean}`, link: "/details/"+product._id});
    }

    setSearchOptions(searchResult);
  } else {
    setSearchOptions([]);
  }
};

  return (
    <>
      <Navbar bg="primary" variant="dark">
        <Container>
          <Navbar.Brand href="/home">
            <img
              alt=""
              src="../images/logo.png"
              width="30"
              height="30"
              className="d-inline-block align-top"
            />
            World of Content
          </Navbar.Brand>
          
          <DropdownButton id="dropdown-basic-button" title="Retailers">
          <Dropdown.Item href="/retailer/albertHeijn">Albert Heijn</Dropdown.Item>
          <Dropdown.Item href="/retailer/jumbo">Jumbo</Dropdown.Item>
          <Dropdown.Item href="/retailer/all">All products</Dropdown.Item>
        </DropdownButton>
          <div>
            <Form.Control onChange={handleSearch} type="search" placeholder="Search"className="me-2" aria-label="Search"/>
            <ListGroup style={{position: "absolute", zIndex:100}}>
              {searchOptions.map((option, key) => (
                <ListGroup.Item key={key} action onClick={event =>  window.location.href=option.link}>{option.title}</ListGroup.Item>
              ))}
              </ListGroup>
          </div>
        </Container>
      </Navbar>
    </>
  );
}

//<RetailerDropdown avaibleOptions={Retailers} activeOption={id}/>

export default NavbarTop;