import ProgressBar from 'react-bootstrap/ProgressBar';

function ProgressbarDetails({ score, total }) {
  return (
    <ProgressBar>
      <ProgressBar variant="primary" now={score} key={1} label={score} max={total} />
      <ProgressBar variant="warning" now={total} key={2} label={total - score} max={total}/>
    </ProgressBar>
  );
}

export default ProgressbarDetails;