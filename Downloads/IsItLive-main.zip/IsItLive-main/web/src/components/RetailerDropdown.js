import React from "react";
import Dropdown from "react-bootstrap/Dropdown";

// Imports
import { Routes, Route, useParams } from "react-router-dom";
import { useState, useEffect } from "react";

// Data imports
import Retailers from "../data/Retailers";

function RetailerDropdown({ avaibleOptions, activeOption }) {
    let { id } = useParams();
    const [activeRetailer, setActiveRetailer] = useState(Retailers[id]);

    

    return (
        <Dropdown className="dropdownButton">
            <Dropdown.Toggle variant="">
            <img
              src={activeRetailer.image}
              alt={activeRetailer.name}
              height="50"
            />
                Change Retailer
            </Dropdown.Toggle>

            <Dropdown.Menu>
                {Object.keys(avaibleOptions).map((option) => {
                    if (option !== activeOption)
                        return (<Dropdown.Item key={option} href={option}>{option}</Dropdown.Item>);
                })}
            </Dropdown.Menu>
        </Dropdown>
    );
}

export default RetailerDropdown;
