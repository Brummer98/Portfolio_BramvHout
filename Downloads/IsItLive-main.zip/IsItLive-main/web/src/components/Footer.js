// React imports
import React, { useState, useEffect } from "react";

// Bootstrap
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "bootstrap/dist/css/bootstrap.min.css";

function Footer() {
  return (
    <>
        <Container fluid className="footerFixed" fixed="bottom">
            <h5>
                Copyright © World of Content 2022
            </h5>
        </Container>
    </>
  );
}

export default Footer;
