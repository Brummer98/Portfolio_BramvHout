import Table from "react-bootstrap/Table";
import React, { useState, useEffect } from "react";
import { Badge } from "react-bootstrap";

function TableProducts({ Rows, ShowRetailer }) {
    return (
      <Table hover>
        <thead>
          <tr>
            {ShowRetailer?(<th>Retailer</th>):""}
            <th>Ean</th>
            <th>Product Description</th>
            <th>Status</th>
            <th>Similarity</th>
          </tr>
        </thead>
        <tbody>
        {Rows && Rows.map((column, key) => (
          <tr key={key} onClick={event => window.location.href="/details/"+column.productID} style={{cursor:"pointer"}}>
            {ShowRetailer?(<th>{column.retailer.name}</th>):""}
            <td>{column.ean}</td>
            <td>{column.opco} {column.productDescription}{column.title}</td>
            <td><Badge bg={(column.status == "live")?"primary":"secondary"}>{column.status}</Badge></td>
            <td>{(column.similarity)?column.similarity+"%":"-"}</td>
          </tr>
        ))}
        </tbody>
      </Table>
    );
}

export default TableProducts;
