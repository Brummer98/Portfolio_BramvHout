import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

export default function Piechart( {liveScore, NotLiveScore} ) {
  const data = {
    labels: ['Not-live', 'Live'],
    datasets: [
      {
        label: 'Livescore overal',
        data: [NotLiveScore, liveScore],
        backgroundColor: [
          // 'rgba(240, 241, 242, 1)',
          'rgba(108, 117, 125, 1)',
          'rgba(5, 131, 242, 1)'
        ],
        borderColor: [
          // 'rgba(240, 241, 242, 1)',
          'rgba(108, 117, 125, 1)',
          'rgba(5, 131, 242, 1)'
        ],
        borderWidth: 2,
      },
    ],
  };
    return <Pie data={data} />;
}