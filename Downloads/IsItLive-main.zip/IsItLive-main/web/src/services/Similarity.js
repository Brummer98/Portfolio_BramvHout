function SimilarityKeyEqualsOrNot(obj1, obj2) {
    let totalItems = 0;
    let equals = 0;

    for (const key of Object.keys(obj1)) {
        // Is value array
        if (Array.isArray(obj1[key])) {
            for (let index = 0; index < obj1[key].length; index++) {
                if (obj1[key][index] == obj2[key][index]) equals++;

                totalItems++;
            }
        } else {
            if (obj1[key] == obj2[key]) equals++;

            totalItems++;
        }
    }

    return (100 / totalItems) * equals;
    //return `${equals} of the ${totalItems} are equal`;
}

export default SimilarityKeyEqualsOrNot;