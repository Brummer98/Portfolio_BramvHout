// Main function
function snapshots(client){
    this.client = client;
}

// Methods
snapshots.prototype.getAll = function (productID, limit) { 
    let request = new URLSearchParams();

    if(productID) request.append("product_id", productID)
    if(limit) request.append("limit", limit)

    return this.client.get(`/api/v1/snapshots?${request.toString()}`);
}; 

snapshots.prototype.getByID = function (snapshotID) { 
    return this.client.get(`/api/v1/snapshots/${snapshotID}`);
}; 

export default snapshots;