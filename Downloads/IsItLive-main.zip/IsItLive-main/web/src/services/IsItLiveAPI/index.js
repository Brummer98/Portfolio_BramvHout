import SimilarityKeyEqualsOrNot from "../Similarity";
import MapDynamicObject from "../Mapper";

import Products from './Products';
import Snapshots from './Snapshots';
import Retailers from './Retailers';

// Main function
function client(){
    this.products = new Products(this);
    this.snapshots = new Snapshots(this);
    this.retailers = new Retailers(this);
}

// Shared mehods
client.prototype.similarityAllProducts = async function (retailerID) { 
    let productSimilarities = []

    // Get all Products
    let products = await this.products.getAll(retailerID);
    let retailers = await this.retailers.getAll();

    // Foreach product get latest Snapshot
    for (const product of products) {
        let latestSnapshot = await this.snapshots.getAll(product._id, 1);

        let productFields = MapDynamicObject(product.dynamicFields);
        let snapshotFields;

        if(latestSnapshot[0])
            snapshotFields = MapDynamicObject(latestSnapshot[0].dynamicFields);

        // Calculate percentage
        let similarity;
        if(snapshotFields && productFields)
            similarity = SimilarityKeyEqualsOrNot(productFields, snapshotFields);

        let retailer = retailers.find(retailer => retailer._id == product.retailer);

        if(productFields.ean)
        productSimilarities.push({
            productID: product._id,
            ...productFields,
            similarity,
            retailer,
            status: (similarity?"live":"failed")
        })
    }

    return productSimilarities;
};


// Utils
client.prototype.status = function () { 
    return this.get("/api/v1/status");
}; 

// Methods
client.prototype.get = function (path) { 
    return this.request(path, "GET");
}; 

client.prototype.post = function (path, body) {
    return this.request(path, "POST", body);
};

// Request
client.prototype.request = async function (path, method, body) {
    const url = new URL("http://localhost:4000"+path);

    var options = {
        method,
    };

    if (method == "POST") 
        options.body = JSON.stringify(body);

    return new Promise((resolve, reject) => {
    fetch(url, options)
        .then(async (response) => {
            let json = await response.json();
            resolve(json)
        })
        .then((data) => reject(data));
    });
};

export default client;