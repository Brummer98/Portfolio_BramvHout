// Main function
function retailers(client){
    this.client = client;
}

// Methods
retailers.prototype.getAll = function () { 
    return this.client.get(`/api/v1/retailers`);
}; 

retailers.prototype.getByID = function (retailerID) { 
    return this.client.get(`/api/v1/retailers/${retailerID}`);
}; 

export default retailers;