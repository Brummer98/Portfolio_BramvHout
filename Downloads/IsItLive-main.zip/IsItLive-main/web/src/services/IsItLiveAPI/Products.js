// Main function
function products(client){
    this.client = client;
}

// Methods
products.prototype.getAll = function (retailerID) { 
    return this.client.get(`/api/v1/products${(retailerID)?"?retailer_id="+retailerID:""}`);
}; 

products.prototype.getByID = function (productID) { 
    return this.client.get(`/api/v1/products/${productID}`);
}; 

export default products;