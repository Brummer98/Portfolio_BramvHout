// Function imports
import MapDynamicObject from "../services/Mapper";
import SimilarityKeyEqualsOrNot from "../services/Similarity";

// React imports
import { Routes, Route, useParams } from "react-router-dom";
import React, { useState, useEffect } from "react";
import axios from "axios";

function DataGetter() {
  let { id } = useParams();
  const [row, setRow] = useState([]);

  // Live data
  const mapRetailer = {
    jumbo: "6389f154345857f06428f345",
    albertHeijn: "63775dca4a8310467a90f33d",
  };

  useEffect(() => {
    axios
      .get(
        `http://localhost:4000/api/v1/products?retailer_id=${mapRetailer[id]}`
      )
      .then(async (response) => {
        let products = response.data;
        let row = [];

        await products.forEach(async (product) => {
          // Set dynamic fields to object
          let productObject = MapDynamicObject(product.dynamicFields);
          let snapshotObject;

          // Get last snapshot based on productID
          await axios
            .get(
              `http://localhost:4000/api/v1/snapshots?product_id=${product._id}&limit=1`
            )
            .then((response) => {
              let snapshot = response.data[0];
              if (snapshot)
                snapshotObject = MapDynamicObject(snapshot.dynamicFields);
            });

          // Calculate similarity
          let similarityPercentage;
          if (snapshotObject)
            similarityPercentage = SimilarityKeyEqualsOrNot(
              productObject,
              snapshotObject
            );

        //   console.log(snapshotObject);

          // Add product to row if not empty
          //if(productObject.ean)
          row.push({
            ean: productObject.ean,
            opco: productObject.opco,
            productDescription: productObject.description,
            status: similarityPercentage ? "Live" : "Not Live",
            similarity: similarityPercentage
              ? `${similarityPercentage}%`
              : "unkown",
          });
        });

        setRow(row);
      });
  }, []);

//   console.log("ID: " + id);
//   console.log(row[0])
//   console.log(row.ean)
}
export default DataGetter;
