function MapDynamicObject(object){
    let resultObject = {}

    for (const field of object) 
        resultObject[field.fieldKey] = (field.fieldValue)?field.fieldValue:field.fieldValues;
    

    return resultObject;
}

export default MapDynamicObject;