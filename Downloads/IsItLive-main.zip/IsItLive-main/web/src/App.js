import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate } from 'react-router-dom';

import "./App.css";
import "./index.css";
import NotFound from "./pages/NotFound";
import Retailer from "./pages/Retailer";
import SelectRetailer from "./pages/SelectRetailer"
import RetailerNotFound from "./pages/RetailerNotFound"
import Detail from "./pages/Detail"
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
    return (
        <div>
            <Routes>
                <Route path="/" element={ <Navigate to="/home" /> } />
                <Route path="/home" element={<SelectRetailer />}  />
                <Route path="/retailer/:retailerName" element={<Retailer />} />
                <Route path="*" element={<NotFound />} />
                <Route path="/retailerNotFound" element={<RetailerNotFound />} />
                <Route path="/details/:productId" element={<Detail />} />
            </Routes>
        </div>
    );
}

export default App;
