import React, { useState, useEffect } from "react";
import "./App.css";
import "./index.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Retailers from "./data/retailers";

import { useParams } from 'react-router-dom';


// Import components
import Ah from "./components/Ah";
import Jumboo from "./components/Jumbo";
import PieChart from "./components/PieChart";
import { ChartData } from "./Data";
import List from "./components/List";
import withListLoading from "./components/withListLoading";


// Bootstrap grid
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import ListGroup from "react-bootstrap/ListGroup";

// Images
const AH = require("./img/AH_logo.png");
const Jumbo = require("./img/Jumbo_logo.png");



function App() {
  let { retailer } = useParams();

  const [activeRetailer, setActiveRetailer] = useState(Retailers.jumbo);

  // Usestates
  //const [retailer, setRetailer] = useState("selectRetailer");
  const [ahContentVisible, setAhContentVisible] = useState(false);
  const [jumboContentVisible, setJumboContentVisible] = useState(false);
  const [chartData, setUserData] = useState({
    labels: ChartData.map((data) => data.liveNotLive),

    datasets: [
      {
        label: "How many products are live",

        data: ChartData.map((data) => data.percentage),

        backgroundColor: ["red", "green"],
      },
    ],
  });
  const ListLoading = withListLoading(List);
  const [appState, setAppState] = useState({
    loading: false,
    retailers: null,
  });


  // UseEffect api
  useEffect(() => {
    setAppState({ loading: true });
    const apiUrl = `https://6343f0a82dadea1175b0c3a7.mockapi.io/Retailer`;
    fetch(apiUrl)
      .then((res) => res.json())
      .then((Retailers) => {
        setAppState({ loading: false, Retailers: Retailers });
      }).catch(err => console.log(err));
  }, [setAppState]);

  // UseEffect Dropdown


  const handleOnChange = (e) => {
    //setRetailer(e.target.value);
  };

  return (
    <>
    <h1>*{retailer}</h1>
    <img src={activeRetailer.logo} alt={activeRetailer.title} width="30%" className="rounded"/>
      <h1>{activeRetailer.title}:{activeRetailer.logo}</h1>
      {/* Nav title */}
      <Container fluid>
        <Row className="rowNav">
          <Col className="supplierCol">
            <h1>Supplier</h1>
            <p>Red Bull</p>
          </Col>
        </Row>
      </Container>

      {/* Pie chart + dropdown */}
      <Container fluid className="containerMain">
        <Row>
          <Col className="colPie">
            <div className="App">
              <div className="piechartData">
                <PieChart chartData={chartData} />
              </div>
            </div>
          </Col>
          <Col className="colImage">

          </Col>
        </Row>
      </Container>

      {/* Table */}
      <Container fluid className="containerBottom">
        <Row>
          <Col>
            <ListGroup variant="flush">
              <ListLoading
                isLoading={appState.loading}
                Retailers={appState.Retailers}
              />
            </ListGroup>
          </Col>
          <Col>
            <ListGroup variant="flush">
              <ListGroup.Item>
                <strong>Products</strong>
              </ListGroup.Item>
              <ListGroup.Item>Red Bull - 250ML </ListGroup.Item>
              <ListGroup.Item>Red Bull - 24 x 250ML</ListGroup.Item>
            </ListGroup>
          </Col>
          <Col>
            <ListGroup variant="flush">
              <ListGroup.Item>
                <strong>Live Score</strong>
              </ListGroup.Item>
              <ListGroup.Item>66%</ListGroup.Item>
              <ListGroup.Item>66%</ListGroup.Item>
            </ListGroup>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default App;
