// Imports
import { Routes, Route, useParams } from "react-router-dom";
import React, { useState, useEffect, useMemo } from "react";

// Bootstrap
import Container from "react-bootstrap/Container";
import "bootstrap/dist/css/bootstrap.min.css";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

import NavbarTop from "../components/Navbar";
import Footer from "../components/Footer";

import Retailers from "../data/Retailers";
import IsItLiveAPIClient from "../services/IsItLiveAPI";
const isItLiveAPIClient = new IsItLiveAPIClient();

function App() {
  // Id and Retailer data
  const [selectedRetailer, setSelectedRetailer] = useState({});
  const [productSimilarity, setProductSimilarity] = useState([]);
  const [overalProductSimilarity, setOveralProductSimilarity] = useState("0");
  const [overalJumboProductSimilarity, setOveralJumboProductSimilarity] =
    useState("0");
  const [overalAhProductSimilarity, setOveralAhProductSimilarity] =
    useState("0");
  const [retailerOptions, setRetailerOptions] = useState([]);
  const [retailers, setRetailers] = useState([{"_id": "1", "name": "test1", "image": "test1.png", "createdAt": "2022-11-18T10:26:18.024Z", "updatedAt":"2022-11-18T10:26:18.024Z", "__v": 0},
  {"_id": "2", "name": "test2", "image": "test2.png", "createdAt": "2022-11-18T10:26:18.024Z", "updatedAt":"2022-11-18T10:26:18.024Z", "__v": 0}]);
  const [selectedRetailerOptions, setSelectedRetailerOptions] = useState([]);

  useEffect(() => {
    isItLiveAPIClient.retailers.getAll().then((retailers) => {
      setRetailers(retailers);
      // Retailer requires similarity
      retailers.forEach((retailer) => {
        if (retailer) {
          console.log(retailer);
          setSelectedRetailer(retailer);

          isItLiveAPIClient
            .similarityAllProducts(retailer._id)
            .then((result) => {
              setProductSimilarity(result);

              const { length } = result;
              let overal = Math.round(
                result.reduce((acc, val) => {
                  return acc + (val.similarity ? val.similarity : 0 / length);
                }, 0) / length
              );

              if (retailer._id == "63775dca4a8310467a90f33d") {
                setOveralAhProductSimilarity(overal);
              }
              if (retailer._id == "6389f154345857f06428f345") {
                setOveralJumboProductSimilarity(overal);
              }
              console.log(overal);
              setOveralProductSimilarity(overal);
            });
        }
      });
    });
  }, []);

  return (
    <>
      <NavbarTop />
      <Container className="ContainerWidgets">
        <Card className="cardRetailer">
          <Card.Img
            variant="top"
            src={"../images/logo.png"}
            className="imageCard"
          />
          <Card.Body>
            <Card.Title>All Retailers</Card.Title>
            <Card.Text>
              An overview of all products from all retailers
            </Card.Text>
            <Button variant="primary" href={"retailer/all"}>
              Go to overview
            </Button>
          </Card.Body>
        </Card>
        
        {/* {retailers.map((retailer) => (
         <Card className="cardRetailer">
            <Card.Img variant="top" src={retailer.image} />
            <Card.Body>
              <Card.Title>{retailer.name}</Card.Title>
              {retailer._id == "6389f154345857f06428f345" && (
                <Card.Text>
                  {retailer.name} has {overalJumboProductSimilarity}% of your
                  products live at this moment!
                </Card.Text>
              )}
              {retailer._id == "63775dca4a8310467a90f33d" && (
                <Card.Text>
                  {retailer.name} has {overalAhProductSimilarity}% of your
                  products live at this moment!
                </Card.Text>
              )}
              <Button variant="primary" href={"retailer/" + retailer.name}>
                Go to {retailer.name}
              </Button>
            </Card.Body>
          </Card>
          ))} */}

        {overalAhProductSimilarity <= 30 && (
          <Card className="cardRetailerRed">
          <Card.Img variant="top" src={retailers[0].image} />
          <Card.Body>
            <Card.Title>{retailers[0].name}</Card.Title>
              <Card.Text>
                {retailers[0].name} has {overalAhProductSimilarity}% of your
                products live at this moment!
              </Card.Text>
              <Button variant="primary" href={"retailer/" + retailers[0].name}>
                Go to {retailers[0].name}
              </Button>
            </Card.Body>
          </Card>
        )}
        {overalAhProductSimilarity > 30 && overalAhProductSimilarity <= 75 && (
          <Card className="cardRetailerOrange">
          <Card.Img variant="top" src={retailers[0].image} />
          <Card.Body>
            <Card.Title>{retailers[0].name}</Card.Title>
              <Card.Text>
                {retailers[0].name} has {overalAhProductSimilarity}% of your
                products live at this moment!
              </Card.Text>
              <Button variant="primary" href={"retailer/" + retailers[0].name}>
                Go to {retailers[0].name}
              </Button>
            </Card.Body>
          </Card>
        )}
        {overalAhProductSimilarity > 75 && (
          <Card className="cardRetailerGreen">
          <Card.Img variant="top" src={retailers[0].image} />
          <Card.Body>
            <Card.Title>{retailers[0].name}</Card.Title>
              <Card.Text>
                {retailers[0].name} has {overalAhProductSimilarity}% of your
                products live at this moment!
              </Card.Text>
              <Button variant="primary" href={"retailer/" + retailers[0].name}>
                Go to {retailers[0].name}
              </Button>
            </Card.Body>
          </Card>
        )}

        {overalJumboProductSimilarity <= 30 && (
          <Card className="cardRetailerRed">
          <Card.Img variant="top" src={retailers[1].image} />
          <Card.Body>
            <Card.Title>{retailers[1].name}</Card.Title>
              <Card.Text>
                {retailers[1].name} has {overalJumboProductSimilarity}% of your
                products live at this moment!
              </Card.Text>
              <Button variant="primary" href={"retailer/" + retailers[1].name}>
                Go to {retailers[1].name}
              </Button>
            </Card.Body>
          </Card>
        )}
        {overalJumboProductSimilarity > 30 && overalJumboProductSimilarity <= 75 && (
          <Card className="cardRetailerOrange">
          <Card.Img variant="top" src={retailers[1].image} />
          <Card.Body>
            <Card.Title>{retailers[1].name}</Card.Title>
              <Card.Text>
                {retailers[1].name} has {overalJumboProductSimilarity}% of your
                products live at this moment!
              </Card.Text>
              <Button variant="primary" href={"retailer/" + retailers[1].name}>
                Go to {retailers[1].name}
              </Button>
            </Card.Body>
          </Card>
        )}
        {overalJumboProductSimilarity > 75 && (
          <Card className="cardRetailerGreen">
          <Card.Img variant="top" src={retailers[1].image} />
          <Card.Body>
            <Card.Title>{retailers[1].name}</Card.Title>
              <Card.Text>
                {retailers[1].name} has {overalJumboProductSimilarity}% of your
                products live at this moment!
              </Card.Text>
              <Button variant="primary" href={"retailer/" + retailers[1].name}>
                Go to {retailers[1].name}
              </Button>
            </Card.Body>
          </Card>
        )}

      </Container>

      <div className="footer-home">
        <Footer />
      </div>
    </>
  );
}
export default App;
