// React imports
import { Routes, Route, useParams } from "react-router-dom";
import React, { useState, useEffect } from "react";
import RetailerNotFound from "./RetailerNotFound";

// Bootstrap imports
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import ProgressBar from "react-bootstrap/ProgressBar";
import "bootstrap/dist/css/bootstrap.min.css";

// Component imports
import ExampleWidget from "../components/ExampleWidget";
import Piechart from "../components/Piechart";
import Card from "react-bootstrap/Card";
import NavbarTop from "../components/Navbar";
import LineChart from "../components/DatumSync";
import Footer from "../components/Footer";
import TableProducts from "../components/TableProducts";
import DropDownAPI from "../components/DropdownAPI";

// Data imports
import IsItLiveAPIClient from "../services/IsItLiveAPI";
const isItLiveAPIClient = new IsItLiveAPIClient();

function App() {
  let { retailerName } = useParams();
  const [selectedRetailer, setSelectedRetailer] = useState({});
  const [productSimilarity, setProductSimilarity] = useState([]);
  const [overalProductSimilarity, setOveralProductSimilarity] = useState("0");
  const [retailerOptions, setRetailerOptions] = useState([]);
  const [selectedRetailerOptions, setSelectedRetailerOptions] = useState([]);
  const [numberOfProducts, setNumberOfProducts] = useState("0");

  var newScore = parseInt(overalProductSimilarity, 10);
  console.log(newScore);

  useEffect(() => {
    isItLiveAPIClient.retailers.getAll().then((retailers) => {
      let selectedRetailer = retailers.find(
        (retailer) => retailer.name == retailerName
      );

      // Add default all
      if (retailerName == "all") {
        selectedRetailer = {
          _id: "",
          name: "all",
        };
      }

      // Retailer requires similarity
      if (selectedRetailer) {
        setSelectedRetailer(selectedRetailer);

        isItLiveAPIClient
          .similarityAllProducts(selectedRetailer._id)
          .then((result) => {
            setProductSimilarity(result);

            const { length } = result;
            let overal = Math.round(
              result.reduce((acc, val) => {
                return acc + (val.similarity ? val.similarity : 0 / length);
              }, 0) / length
            );

            setOveralProductSimilarity(overal);
            // numberOfProducts = result.length;
            setNumberOfProducts(result.length);
            console.log(numberOfProducts);
          });
      }
    });
  }, []);

  if (!selectedRetailer.name) {
    return <RetailerNotFound />;
  }

  return (
    <>
      <NavbarTop />
      <Container className="ContainerWidgetsTop">
        <Row>
          <Col>
            <h5>Overal livescore:</h5>
            <ProgressBar>
              <ProgressBar
                variant="primary"
                now={newScore}
                key={1}
                label={"Live: " + newScore + "%"}
                max={100}
              />
              <ProgressBar
                variant="warning"
                now={100 - newScore}
                key={2}
                label={"Not live: " + (100 - newScore) + "%"}
                max={100}
              />
            </ProgressBar>
          </Col>
          <Col>
            <h5>Total amount of products</h5>
            <p>{numberOfProducts}</p>
          </Col>
        </Row>
      </Container>
      <Container className="ContainerWidgets">
        <Row className="RowWidgets">
          <Col className="ColWidget">
            <h3 className="titleWidget">Products and livescore</h3>
            <TableProducts
              Rows={productSimilarity}
              ShowRetailer={selectedRetailer.name == "all"}
            />
          </Col>
        </Row>
      </Container>
      <Footer />
    </>
  );
}
export default App;

/*
<Row className="RowWidgets align-items-center text-center">
          <Col xs={7} className="ColWidget">
            <h3 className="titleWidget">Live & not Live</h3>
            <ProgressBar>
              <ProgressBar
                variant="primary"
                now={overalProductSimilarity}
                key={1}
                label={`Live: ${overalProductSimilarity}%`}
              />
              <ProgressBar
                variant="secondary"
                now={100-overalProductSimilarity}
                key={2}
                label={`Not live: ${100-overalProductSimilarity}%`}
              />
            </ProgressBar>
            <br />
          </Col>
          <Col xs={1}></Col>
          <Col xs={4} className="ColWidget">
            <h3 className="titleWidget">Total amount of products</h3>
            <div className="textWidget">
              <p className="totalNr">{productSimilarity.length}</p>
              <hr className="lineTotalAmounts"></hr>
              <p className="totalNrText">Products available</p>
            </div>
          </Col>
        </Row>
        <Row className="RowWidgets">
          <Col xs={7} className="ColWidget">
            <h3 className="titleWidget">Date of sync</h3>
            <LineChart style={{ height: 200 }} />
          </Col>
          <Col xs={1}></Col>
          <Col xs={4} className="ColWidget">
            <h3 className="titleWidget">Overal live score</h3>
            <Piechart liveScore={""} NotLiveScore={""} />
          </Col>
        </Row>
        <Row className="RowWidgets">
          <Col className="ColWidget">
            <h3 className="titleWidget">Products list</h3>
            <TableProducts Rows={productSimilarity} />
          </Col>
        </Row>
      </Container>
      <Footer />
    </div>
  );
}*/
