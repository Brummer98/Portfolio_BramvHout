// React imports
import { Routes, Route, useParams, useSearchParams } from "react-router-dom";
import React, { useState, useEffect, useRef } from "react";

// Bootstrap imports
import "bootstrap/dist/css/bootstrap.min.css";
import Form from "react-bootstrap/Form";
import Card from "react-bootstrap/Card";
import ListGroup from "react-bootstrap/ListGroup";

// Component imports
import NavbarTop from "../components/Navbar";
import ProgressbarDetails from "../components/ProgressbarDetails";
import Footer from "../components/Footer";

// Data imports
import MapDynamicObject from "../services/Mapper";
import IsItLiveAPIClient from "../services/IsItLiveAPI";
const isItLiveAPIClient = new IsItLiveAPIClient();

function App() {
  let { productId } = useParams();
  let liveCount = 0;
  const [searchParams, setSearchParams] = useSearchParams();
  const [product, setProductS] = useState({});
  const [snapshot, setSnapshot] = useState([]);
  const [snapshots, setSnapshots] = useState([]);
  const snapshotsRef = useRef();
  snapshotsRef.current = snapshots;

  function setSnapshotsHandler(snapshots) {
    let selectSnapshotId = searchParams.get("snapshotId");
    if (!selectSnapshotId) selectSnapshotId = snapshots[0]._id;
    selectedSnapshot(selectSnapshotId, snapshots);

    setSnapshots(snapshots);
  }

  useEffect(() => {
    isItLiveAPIClient.products.getByID(productId).then((product) => {
      let object = MapDynamicObject(product.dynamicFields);
      setProductS(object);
    });
    isItLiveAPIClient.snapshots.getAll(productId).then((snapshots) => {
      setSnapshotsHandler(snapshots);
    });
  }, []);

  const handleChangeSnapshot = (event) => {
    setSearchParams({ snapshotId: event.target.value });
    selectedSnapshot(event.target.value, snapshotsRef.current);
  };

  const selectedSnapshot = (selectSnapshotId, snapshots) => {
    let selectedSnapshot = snapshots.find(
      (snapshot) => snapshot._id == selectSnapshotId
    );

    if (selectedSnapshot)
      setSnapshot(MapDynamicObject(selectedSnapshot.dynamicFields));
  };

  return (
    <>
    <div>
      <NavbarTop />

      <div className="container mt-5">
      <h1>Details</h1>
      <p className="lead">The result below contains 3 values, these exist of "name", "product value", "snapshot value". When the snapshot value is "no reference" it means that the name does not exist in a snapshot.</p>
      <div> 
      <Card id="cardExample" >
        <Card.Header>Name</Card.Header>
        <ListGroup className="list-group-flush">
          <ListGroup.Item>Product value</ListGroup.Item>
          <ListGroup.Item>Snapshot value</ListGroup.Item>
        </ListGroup>
      </Card>
      </div>
      <Form.Group className="mb-3" style={{display: 'inline-block', width: 'auto'}}>
        <Form.Label>Change snapshot:</Form.Label>
        <Form.Select onChange={handleChangeSnapshot} aria-label="Default select example" >
          {snapshots && snapshots.map((snapshot, key) => (
            <option key={key} value={snapshot._id}>{new Date( Date.parse(snapshot.createdAt)).toLocaleString()}</option>
          ))}
        </Form.Select>
      </Form.Group>
      

    <hr></hr>

      <div>
      {product && Object.keys(product).map((productProp, key) => {if(product[productProp] == snapshot[productProp]) liveCount++; return (
            <Card key={key} className={(product[productProp] != snapshot[productProp])?"text-bg-warning m-2 d-inline-flex":"m-2 d-inline-flex"}>
              <Card.Header>{productProp}</Card.Header>
              <ListGroup className="list-group-flush">
                <ListGroup.Item>{product[productProp]}</ListGroup.Item>
                <ListGroup.Item>{(snapshot[productProp])?snapshot[productProp]:"No refrence!"}</ListGroup.Item>
              </ListGroup>
            </Card>
          )})}
      </div>
      <div className="containerPGB">
        <span>{liveCount} of the {Object.keys(product).length} are correct</span>
        <ProgressbarDetails 
        score={liveCount}
        total={Object.keys(product).length}
        />
      </div>
      </div>
      
    </div>
    <Footer />
    </>
  );
}
export default App;
