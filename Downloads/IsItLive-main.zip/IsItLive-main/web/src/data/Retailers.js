export default {
    jumbo: {
        logo: "/images/jumbo_logo.png",
        title: "Jumbo",
        data: {
            
        }
    },
    albertHeijn: {
        logo: "/images/albertHeijn_logo.png",
        title: "AlbertHeijn"
    }
}