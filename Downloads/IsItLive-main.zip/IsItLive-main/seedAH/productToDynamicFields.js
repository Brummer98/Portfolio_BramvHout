var http = require('http');
const fs = require("fs");
const data = JSON.parse(fs.readFileSync('./data/product_examples.json','utf8'));

const config = {
    retailerId: "63775dca4a8310467a90f33d",
}

data.forEach(product => {
    var postData = JSON.stringify({
        retailer: config.retailerId,
        dynamicFields: mapObjectToDynamicObject(product)
    });
    
    var options = {
        method: 'POST',
        hostname: 'localhost',
        port: 4000,
        path: '/api/v1/products',
        headers: {
          'Content-Type': 'application/json'
        },
    };
    var req = http.request(options, function (res) {
        var chunks = [];
      
        res.on("data", function (chunk) {
          chunks.push(chunk);
        });
      
        res.on("end", function (chunk) {
          var body = Buffer.concat(chunks);
          console.log(body.toString());
        });
      
        res.on("error", function (error) {
          console.error(error);
        });
      });
    
    req.write(postData);
    
    req.end();
});

function mapObjectToDynamicObject(object){
    let result = [];

    Object.keys(object).forEach(key => {
        let dynamicField = {fieldKey:key}

        if(typeof object[key] === 'string')
            dynamicField.fieldValue = object[key];

        if(Array.isArray(object[key]))
            dynamicField.fieldValues = object[key];

        result.push(dynamicField)
    });

    return result;
}